package com.capstone.cap.controller;

import com.capstone.cap.dto.GPTRequest;
import com.capstone.cap.dto.Message;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

/**
 * GPT API 연동용 컨트롤러
 * 내부에서 고정된 message 배열을 구성하여 OpenAI Chat API로 요청을 보냄
 */
@RestController
@RequestMapping("/gpt")
@RequiredArgsConstructor
public class GPTController {

    @Value("${gpt.model}")        // application.properties에서 모델명 로딩
    private String model;

    @Value("${gpt.api.url}")      // OpenAI API URL 로딩
    private String apiUrl;

    @Value("${gpt.api.key}")      // API 키 로딩
    private String apiKey;

    private final RestTemplate restTemplate;  // Spring HTTP 클라이언트

    /**
     * GET /gpt/chat 요청 시 실행
     * OpenAI에 메시지 배열을 POST로 전달하여 응답을 반환
     */
    @GetMapping("/chat")
    public String chat() throws JsonProcessingException {
        // 메시지 리스트 생성
        List<Message> messages = new ArrayList<>();
        messages.add(new Message("system", "너는 계획을 만들어주는 도우미야")); // 시스템 역할 설정
        messages.add(new Message("assistant", "응답은 json형식으로 해줘 예시:'아침':'산책30분':'이운동을 하는 간단한 팁','점심':'스트레칭','저녁':'러닝1시간' 그리고 그 행동에 대해 간단한 팁도 보여줘야해"));
        messages.add(new Message("user", "간단한 하루 운동계획을 만들어줘"));

        // GPT 요청 본문 구성
        GPTRequest requestBody = new GPTRequest();
        requestBody.setModel(model);            // 사용할 모델
        requestBody.setMessages(messages);      // 메시지 배열
        requestBody.setTemperature(1.0);        // 창의성 (0~2)
        requestBody.setMax_tokens(256);         // 최대 응답 길이

        // HTTP 요청 헤더 설정
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey); // Authorization: Bearer <API_KEY>

        // HTTP 요청 객체 구성
        HttpEntity<GPTRequest> request = new HttpEntity<>(requestBody, headers);

        // 요청 JSON 로그 출력 (디버깅용)
        ObjectMapper mapper = new ObjectMapper();
        System.out.println("REQ JSON: " + mapper.writeValueAsString(requestBody));

        // GPT API에 요청 보내고 응답 받기
        ResponseEntity<String> response = restTemplate.postForEntity(apiUrl, request, String.class);

        // GPT 응답 본문 반환
        return response.getBody();
    }
}
